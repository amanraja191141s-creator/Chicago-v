# SA Calculator — Tools Only v100.04

This is the tools-only release containing 12 tool workspaces in three categories. The shared numeric keypad and calculation engine remain as internal dependencies.

## Android APK build
The GitHub Actions workflow is `.github/workflows/main.yml`. It uses the runner-preinstalled Android SDK rather than `android-actions/setup-android@v3`, because the supplied failed run shows that action invoking the removed `sdkmanager tools` package.

The workflow installs only:
- `platform-tools`
- `platforms;android-35`
- `build-tools;35.0.0`

It then installs pinned Capacitor 7.4.3 dependencies, runs regression tests, generates/synchronizes the Android project, applies native branding and insets, builds `assembleDebug`, verifies package metadata, and uploads the APK artifact.

## Run locally
- Node.js 22
- `npm install --no-package-lock`
- `npm run test:release`
- `npm run android:setup`
- `cd android && ./gradlew assembleDebug`
