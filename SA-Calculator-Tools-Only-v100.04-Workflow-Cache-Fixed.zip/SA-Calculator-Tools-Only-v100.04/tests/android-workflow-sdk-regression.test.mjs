import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

test('Android workflow avoids removed sdkmanager tools package', () => {
  const yml = readFileSync(new URL('../.github/workflows/main.yml', import.meta.url), 'utf8');
  assert.doesNotMatch(yml, /android-actions\/setup-android@/);
  assert.doesNotMatch(yml, /sdkmanager\s+tools(?:\s|$)/);
  assert.match(yml, /platform-tools/);
  assert.match(yml, /platforms;android-35/);
  assert.match(yml, /build-tools;35\.0\.0/);
  assert.match(yml, /dump badging/);
});

test('Node setup does not require a missing npm lockfile for dependency caching', () => {
  const yml = readFileSync(new URL('../.github/workflows/main.yml', import.meta.url), 'utf8');
  const nodeStep = yml.split('- name: Set up Node.js 22')[1]?.split('- name:')[0] ?? '';
  assert.match(nodeStep, /node-version:\s*22/);
  assert.doesNotMatch(nodeStep, /^\s*cache:/m);
  assert.doesNotMatch(nodeStep, /cache-dependency-path:/);
  assert.match(nodeStep, /package-manager-cache:\s*false/);
  assert.match(yml, /actions\/checkout@v7/);
  assert.match(yml, /actions\/setup-node@v7/);
  assert.match(yml, /actions\/setup-java@v5/);
  assert.match(yml, /actions\/upload-artifact@v7/);
  assert.match(yml, /npm install --no-package-lock/);
});
