# SA Calculator v99.02 — Tool surfaces removed; shared keypad retained

Mobile-first standard and scientific calculator. All individual tool screens and tool launchers have been removed from the rendered application; the shared numeric tool keypad remains in the project.

## Release identity
- App version: `1.99.16-v99.02`
- Android versionCode: `1099131`
- Service-worker cache: `sa-calculator-v99-02-tools-removed-keypad-only-v9902`

## What remains
- Standard calculator and scientific calculator
- Main calculator keypad and shared numeric tool keypad (15 keys)
- History, settings, themes, localization and app shell

## What was removed from the rendered app
- Currency Converter and every other individual tool workspace
- Tool launcher cards, tool search/categories and tool favorites UI
- Tool startup initialization, currency-rate refresh startup and world-time polling startup
- Tool-only stylesheet loading

## Verify locally
```sh
npm run test:release
npm run build:web
```

## Android build
Use `.github/workflows/main.yml` or `sa-calculator-v99.02-android.yml` in GitHub Actions. The archive does not contain a prebuilt APK.

## Validation boundary
Automated checks cover source structure, keypad retention, JavaScript syntax, calculator regression, web-bundle synchronization and workflow consistency. Physical Android APK installation, visual layout and touch interaction still require a device run. Legacy tool helper definitions and the unreferenced historical tool stylesheet file remain in the source tree for safe dependency compatibility; they are not initialized or loaded by the app.
